/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp;

import com.codename1.components.ImageViewer;
import com.codename1.components.SpanLabel;
import com.codename1.db.Cursor;
import com.codename1.db.Database;
import com.codename1.db.Row;
import com.codename1.ui.Command;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import entity.House;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.list.DefaultListModel;
import com.codename1.ui.list.MultiList;
import com.codename1.ui.util.Resources;
import entity.House;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author Walid Jlassi
 */
public class HouseList extends Form{
    Database db;
    ArrayList<House> houses = new ArrayList<>();
    // Create a new DefaultListModel for the MultiList
     //It provides a simple way to store and manage a list of objects
    public HouseList(Resources theme) {
        super("Database Rows", BoxLayout.y());
        this.setTitle("House List");
        
        
        
        
         this.RenderHouses();
        //getToolbar
        
        //Add
        this.getToolbar().addCommandToRightBar("Add", null, (ActionListener) (ActionEvent evt) -> {
        HouseAdd HA = new HouseAdd(theme);
        HA.show();
        });
        
        //Update
        this.getToolbar().addCommandToSideMenu("Update", null, (ActionListener) (ActionEvent evt) -> {
        HouseUpdate HU = new HouseUpdate(theme);
        HU.show();                
        });        
        
        //Delete
        this.getToolbar().addCommandToSideMenu("Delete", null, (ActionListener) (ActionEvent evt) -> {
        HouseDel HD = new HouseDel(theme);
        HD.show();                
        });  
        
        //Back
        this.getToolbar().addCommandToLeftBar("", theme.getImage("icons8-back-arrow-90.png"), (ActionListener) (ActionEvent evt) -> {
        Menu m = new Menu(theme);
        m.show();
        }); 
    }
    //Methods
     public void RenderHouses()
     {
                 try {
            db = Database.openOrCreate("esprit");
            db.execute("create table if not exists HousesRent ( id TEXT , nom TEXT , NumberBedrooms TEXT , Bathroom TEXT , FurnishingStatus TEXT , City Text , price TEXT , PointOfContact TEXT );");    
            Cursor cur = db.executeQuery("select * from HousesRent");
            while (cur.next()) {
                Row row = cur.getRow();
                House h = new House(row.getString(0),row.getString(1),row.getString(2),row.getString(3),row.getString(4),row.getString(5),row.getString(6),row.getString(7));
                if (!(houses.contains(h)))
                {
                    houses.add(h);
                
                     Label labelName = new Label(h.getNom());
                     Label labelPrice = new Label(h.getPrix());
                    
                    labelName.addPointerPressedListener((ActionListener) (ActionEvent evt) -> {
                    Dialog.show("House Details", "Id : " + h.getId() + " \n \n Nom : " + h.getNom() + " \n \n NumberBedrooms  : " + h.getNumberBedrooms() + " \n \n Bathroom  : " + h.getBathroom()+ " \n \n City  : " + h.getFurnishingStatus() + " \n \n FurnishingStatus  : " + h.getCity() + " \n \n Price : " + h.getPrix() + " \n \n PointOfContact  : " + h.getPointOfContact() +"\n", "Ok", null);
                });
                
                this.add(labelName);
                this.add(labelPrice);  
                }              
                
            }
            // Close the cursor and the database
            cur.close();
            db.close();
        } catch (IOException e) {
            System.out.println(""+e.getMessage());
        }
     }
     
}
