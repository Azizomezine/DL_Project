/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myapp;
import com.codename1.db.Cursor;
import com.codename1.db.Database;
import com.codename1.db.Row;
import com.codename1.ui.Button;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import entity.House;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.list.DefaultListModel;
import com.codename1.ui.list.MultiList;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.Resources;
import entity.House;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import entity.House;
/**
 *
 * @author Walid Jlassi
 */
public class HouseAdd extends Form {
    Database db;
    
    public HouseAdd(Resources theme) {
    //Declaration
    HouseList HL = new HouseList(theme);
    Container C = new Container(new BoxLayout(BoxLayout.Y_AXIS));
    //super(new BorderLayout());
    this.setTitle("House Add");
    //Labels
    TextField Id = new TextField("","House Id");
    TextField tfNom = new TextField("","House Name");
    TextField NumberBedrooms = new TextField("","Bedrooms Number");
    TextField Bathroom = new TextField("","Bathroom Number");
    TextField FurnishingStatus = new TextField("","Furnished or Semi-Furnished or Unfurnished");
    TextField City = new TextField("","City Name");
    TextField tfPrix = new TextField("","House Price");
    TextField PointOfContact = new TextField("","Phone Number");
    
    //Button
    Button btn = new Button("Valider");
    //Add to Container and Form    
    C.add(Id);
    C.add(tfNom);
    C.add(NumberBedrooms);
    C.add(Bathroom);
    C.add(FurnishingStatus);
    C.add(City);
    C.add(tfPrix);
    C.add(PointOfContact);
    C.add(btn);
    this.add(C);
  
    //buttons
    //Add
    btn.addActionListener((ActionListener) new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent evt1) {
            House c = new House(Id.getText(), tfNom.getText(), NumberBedrooms.getText(), Bathroom.getText(), FurnishingStatus.getText(), City.getText(), tfPrix.getText(), PointOfContact.getText());        
            try {               
                //Open DB
                db = Database.openOrCreate("esprit");
                //Check Existance 
                Cursor cursor = db.executeQuery("SELECT * FROM HousesRent WHERE id=?", new Object[] { tfNom.getText() });
                //Existed
                if (cursor.next()) {
                // Display an error message 
                Dialog.show("House","Exist" ,"Ok", null);
                // Close the database
                db.close();
                // Return To Form
                HL.show();
                }
                else
                {
                    // Insert To DB
                    db.execute("insert into HousesRent (id , nom , NumberBedrooms , Bathroom  , FurnishingStatus , City , price ,PointOfContact ) VALUES (? , ? , ? , ? , ? , ? , ? , ?); ", new Object[] { Id.getText(), tfNom.getText(), NumberBedrooms.getText(), Bathroom.getText(), FurnishingStatus.getText(), City.getText(), tfPrix.getText(), PointOfContact.getText() });
                    
                    // Clear the text fields
                    Id.setText("");
                    tfNom.setText("");
                    NumberBedrooms.setText("");
                    Bathroom.setText("");
                    City.setText("");
                    FurnishingStatus.setText("");
                    tfPrix.setText("");
                    PointOfContact.setText("");
                                                          
                    // Close the database
                    db.close();
                    
                    // Return To Form
                    HouseList HL1 = new HouseList(theme);
                    HL1.show();
                }
                cursor.close();
            }
            catch (Exception ex) {
                ex.printStackTrace();               
                // Display an error message
                Label errorLabel = new Label("Error adding row: " + ex.getMessage());
                add(errorLabel);
            }
        }
    });
    
    
    
    this.getToolbar().addCommandToLeftBar("", theme.getImage("icons8-back-arrow-90.png"), (ActionListener) (ActionEvent evt) -> {
        //Return To Form
        HL.showBack();
        }); 
    }
}
