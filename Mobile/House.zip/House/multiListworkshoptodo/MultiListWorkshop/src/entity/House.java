/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Walid Jlassi
 */
public class House {
    private String id;
    private String nom;
    private String NumberBedrooms ; 
    private String Bathroom ;
    private String City ;
    private String FurnishingStatus ;
    private String prix;
    private String PointOfContact ;

    public House(String id, String nom, String NumberBedrooms, String Bathroom, String City, String FurnishingStatus, String prix, String PointOfContact) {
        this.id = id;
        this.nom = nom;
        this.NumberBedrooms=NumberBedrooms;
        this.Bathroom=Bathroom;
        this.City=City;
        this.FurnishingStatus=FurnishingStatus;
        this.prix=prix;
        this.PointOfContact=PointOfContact;           
    }
    
    //Getters And Setters
    
    public String getPrix() {
        return prix;
    }

    public String getNom() {
        return nom;
    }
    
    public String getId() {
        return id;
    }
   
    public void setId(String id) {
        this.id = id;
    }
   
    public void setNom(String nom) {
        this.nom = nom;
    }
   
    public String getNumberBedrooms() {
        return NumberBedrooms;
    }
    
    public void setNumberBedrooms(String NumberBedrooms) {
        this.NumberBedrooms = NumberBedrooms;
    }
   
    public String getBathroom() {
        return Bathroom;
    }
   
    public void setBathroom(String Bathroom) {
        this.Bathroom = Bathroom;
    }
    
    public String getCity() {
        return City;
    }
   
    public void setCity(String City) {
        this.City = City;
    }
   
    public String getFurnishingStatus() {
        return FurnishingStatus;
    }
   
    public void setFurnishingStatus(String FurnishingStatus) {
        this.FurnishingStatus = FurnishingStatus;
    }
   
    public void setPrix(String prix) {
        this.prix = prix;
    }
  
    public String getPointOfContact() {
        return PointOfContact;
    }

    public void setPointOfContact(String PointOfContact) {
        this.PointOfContact = PointOfContact;
    }

    
}
